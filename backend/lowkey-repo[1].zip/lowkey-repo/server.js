// LOWKEY server – zero dependencies. Run: node server.js  (http://localhost:3000)
const http=require('http'),fs=require('fs'),path=require('path');
const Core=require('./shared/core.js'),SEED=require('./data/seed.js');Core.seed=SEED;
const DBF=path.join(__dirname,'data','db.json');
let db;try{db=JSON.parse(fs.readFileSync(DBF,'utf8'))}catch(e){db=JSON.parse(JSON.stringify(SEED))}db.sess={};
const save=()=>{try{const{sess,...d}=db;fs.writeFileSync(DBF,JSON.stringify(d,null,1))}catch(e){}};
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css'},OK=/^\/(index\.html|css\/|js\/|shared\/|data\/seed\.js)/;
const send=(res,s,d)=>{res.writeHead(s,{'Content-Type':'application/json'});res.end(JSON.stringify(d))};
http.createServer((req,res)=>{
 if(req.url.startsWith('/api/')){let b='';req.on('data',c=>b+=c);req.on('end',()=>{let body={};try{if(b)body=JSON.parse(b)}catch(e){return send(res,400,{error:'Invalid JSON'})}
  const tok=(req.headers.authorization||'').replace('Bearer ','');const r=Core.route(db,save,req.method,req.url,body,tok);send(res,r.status,r.data)});return}
 const u=decodeURIComponent(req.url.split('?')[0]),rel=u=='/'?'/index.html':u,f=path.join(__dirname,rel);
 if(!OK.test(rel)||rel.includes('..')||!fs.existsSync(f)){res.writeHead(404);return res.end('Not found')}
 res.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'text/plain'});fs.createReadStream(f).pipe(res)
}).listen(process.env.PORT||3000,()=>console.log('LOWKEY running at http://localhost:'+(process.env.PORT||3000)));
